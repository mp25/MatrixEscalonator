package MatrixEscalonator.Principal.com;

public class TesteExpressao2 {

	public static void main(String[] args) {
		String[][] expre = {{"+3x + x +5x = 60"},{"-5y-1y = 20"},{" z  - 6z = 235"}};

		String valor = "";
		int indice = 0;
		String termo = "";
		String[] vet = new String[expre.length];
		int cont = 0;
		
		for (int i = 0; i < expre.length; i++) {
			for (int j = 0; j < expre[i].length; j++) {
				valor = 
				if (expre.charAt(i) == '=') {
					termo = expre.substring(0, i + 1);
					vet[cont] = expre.substring(i + 1, expre.length());
					i = expre.length();
				} else if (Character.isLetter(expre.charAt(i))) {
					indice = expre.indexOf(i);
					termo = expre.substring(0, i + 1);
					vet[cont] = termo;
					expre = expre.substring(i + 1, expre.length());
					i = -1;
					cont++;
				}

			}
			
		}
		ExtraiTermosVetor(vet);
	}

	public static void ExtraiTermosVetor(String[] expre) {
		String[] vet = new String[expre.length];
		StringBuilder expressaoTermoX = new StringBuilder();
		StringBuilder expressaoTermoY = new StringBuilder();
		StringBuilder expressaoTermoZ = new StringBuilder();
		Character valor = null;
		for (int i = 0; i < expre.length; i++) {
			if (expre[i] != "" && expre[i] != null) {
				if (expre[i].contains("x")) {
					expressaoTermoX.append(expre[i]);
				}
				if (expre[i].contains("y")) {
					expressaoTermoY.append(expre[i]);
				}
				if (expre[i].contains("z")) {
					expressaoTermoZ.append(expre[i]);
				}
			}
			
			else
				break;
		}

		System.out.println(expressaoTermoX);
		System.out.println(expressaoTermoY);
		System.out.println(expressaoTermoZ);
		
	}
	
	public static void CalculaExpressao(String expre){
		

		
		
	}


}
