package MatrixEscalonator.Principal.com;

public class TesteExpresso {

	public static void main(String[] args) {

		String expre = "-1y + z = 2";
		Character sinal = null;
		StringBuilder termo = new StringBuilder();
		String termoIndividual = "";
		int[] vet = new int[10];
		expre = expre.replace(" ","");
		for (int i = 0; i < expre.length(); i++) {
			Character valor = expre.charAt(i);
			if (valor == '+' || valor == '-') {
				sinal = valor;
			}
			if (Character.isLetter(valor)) {
				termoIndividual = "1";
				if(termoIndividual.contains("-")){
					termo.append(sinal.toString() + valor.toString());
					termoIndividual = sinal.toString() + valor.toString();
				}else
					termo.append(valor.toString());
			}
			if (termoIndividual.matches("[1-9]")) {
				if (sinal != null) {
					termo.append(sinal.toString() + valor.toString());
					//termoIndividual = sinal.toString() + valor.toString();
					vet[i] = (int) Float.parseFloat(termoIndividual);
					
				} else {
					termo.append(valor.toString());
					termoIndividual = valor.toString();
					vet[i] = Integer.parseInt(termoIndividual);
				}
			}
		
		}
		System.out.println(termo);

	}

}
